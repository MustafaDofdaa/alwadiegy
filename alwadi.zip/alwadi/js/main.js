 // Implementation of google map
  
 function initMap() {
        // The location of Uluru
        const Damanhour = { lat: 31.042458, lng: 30.472750 };
        // The map, centered at Uluru
        const map = new google.maps.Map(document.getElementById("map"), {
          zoom: 4,
          center: Damanhour,
        });
  // The marker, positioned at Uluru
        const marker = new google.maps.Marker({
          position: Damanhour,
          map: map,});
      }

  // smoothscrolling
  $("#navbar a, .btn").on("click", function(event) {
  if(this.hash !==""){
  event.preventDefault();
  $("html, body").animate({scrolltop: $(hash).offset().top-100},800);
}
});

  // Navbar Opacity
  window.addEventListener("scroll",function() {
  if(window.scrolly > 150){
  document.querySelector("#navbar").style.opacity = 0,9;
  }else{
  document.querySelector("#navbar").style.opacity = 1;
  }
})

    